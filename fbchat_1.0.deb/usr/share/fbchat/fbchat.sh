#!/bin/bash

clear

sensible-browser --new-window=/usr/share/fbchat/index.html &

clear
